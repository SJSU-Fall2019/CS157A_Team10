import React from 'react'

function About()
{
  return (
    <div>
      <h1>About</h1>
      <p>This the the TodoList app</p>
    </div>
  )
}


export default About;
