import React from 'react';

/**
  * @desc Functional function header
  * @desc Functional function header
  * @desc Functional function header
*/
function PlaceHolder()
{
  return (
    <div>
      <div style  = {divStyle}></div>
    </div>

  )
}


const divStyle =
{
   flex : '6',
   background:'#1F70C1',
}



export default PlaceHolder;
