# Scope

Go to the NodeJS folder  
Open NodeJS folder with an editor  
Find the portion where says "var connection = mysql.createConnection"  
Edit the user and password according to your local database (Suggest using the same user and database for homework1)  
Root should works fine, other users may required permission  





Open two separate Terminal

First Terminal(For the backend server)
cd Scope  
cd NodeJS  
Node server.js  


Second Terminal(For the react)
cd Scope  
npm start  
